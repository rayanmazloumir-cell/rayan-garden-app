# Rayan Garden Flutter — Step 1

First UI milestone:
- Flutter project structure
- Persian RTL home screen
- Cream, deep-green and gold theme
- Approved garden preview image bundled as an asset

## Run
1. Install Flutter SDK and Android Studio.
2. Extract this ZIP.
3. Run `flutter pub get` in the project directory.
4. Connect an Android phone with USB debugging enabled or start an emulator.
5. Run `flutter run`.

## Scope
This is a UI prototype, not a finished APK.
The booking button is a placeholder. API calls, booking submission, payments,
authentication and SMS are not implemented yet.
No website files or server APIs have been changed.
The hero image can be replaced later without changing the app structure.
