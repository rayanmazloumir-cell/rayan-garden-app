/// Central place for fixed business rules and contact details.
/// Nothing secret lives here: only public information and booking rules.
class AppConfig {
  AppConfig._();

  static const String apiBase = 'https://rayangarden.com/api/';
  static const Duration requestTimeout = Duration(seconds: 20);

  // Booking rules (as provided by the business).
  static const int openHour = 6; // 06:00
  static const int closeHour = 20; // 20:00
  static const int slotStepMinutes = 30;
  static const int minLeadMinutes = 60;
  static const int maxAheadDays = 120;
  static const int minElapsedMs = 2500;
  static const int unconfirmedHoldHours = 24;

  // Iran uses a fixed UTC+03:30 offset (no daylight saving since 2022).
  static const Duration tehranOffset = Duration(hours: 3, minutes: 30);

  // Public contact details.
  static const String phone = '09126605578';
  static const String email = 'Rayan.Garden.ir@gmail.com';
  static const String instagramUser = 'rayangarden';
  static const String mapsUrl = 'https://maps.app.goo.gl/xgQ83dKfkBsaJPL26';
}
