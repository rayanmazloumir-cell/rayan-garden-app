/// A bookable service as returned by `services.php`.
/// [id] is kept exactly as the server sent it (number or string).
class ServiceItem {
  const ServiceItem({
    required this.id,
    required this.name,
    this.nameEn,
    this.durationMinutes,
    this.description,
  });

  final Object id;
  final String name;
  final String? nameEn;
  final int? durationMinutes;
  final String? description;

  String displayName(bool fa) =>
      (!fa && nameEn != null && nameEn!.isNotEmpty) ? nameEn! : name;
}

/// Known durations from the business rules. Used ONLY when the server does not
/// send a duration for a service; the server value always wins.
const Map<String, int> fallbackDurations = {
  'عکاسی عروس و داماد': 180,
  'عکاسی فرمالیته': 180,
  'عکاسی کودک': 60,
  'عکاسی خانوادگی': 60,
  'عکاسی پرتره': 60,
  'کافه باغ': 120,
  'لوکیشن': 120,
  'بازدید': 30,
};

int? fallbackDurationFor(String name) {
  final n = name.trim();
  final exact = fallbackDurations[n];
  if (exact != null) return exact;
  // Longest key first so a long name never matches a shorter key.
  final keys = fallbackDurations.keys.toList()
    ..sort((a, b) => b.length.compareTo(a.length));
  for (final k in keys) {
    if (n.contains(k)) return fallbackDurations[k];
  }
  return null;
}
