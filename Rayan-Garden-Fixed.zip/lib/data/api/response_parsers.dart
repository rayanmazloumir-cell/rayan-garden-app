import '../../core/utils/digits.dart';
import '../models/booking.dart';
import '../models/service_item.dart';
import '../models/slot_time.dart';
import 'api_exception.dart';

// ---------------------------------------------------------------------------
// IMPORTANT: the exact JSON shape of services.php / availability.php was not
// documented. These parsers are deliberately tolerant and isolated in this one
// file. If a real response does not match, an ApiException(format) is raised
// carrying the raw body so the shape can be confirmed and fixed here only.
// The only response fields taken from the documented contract are `ref` and
// `status` of book.php.
// ---------------------------------------------------------------------------

const List<String> _listKeys = [
  'services', 'data', 'items', 'result', 'results',
  'slots', 'times', 'available', 'availability', 'hours',
];

dynamic _firstOf(Map map, List<String> keys) {
  for (final k in keys) {
    if (map.containsKey(k) && map[k] != null) return map[k];
  }
  return null;
}

String? _firstString(Map map, List<String> keys) {
  for (final k in keys) {
    final v = map[k];
    if (v is String && v.trim().isNotEmpty) return v.trim();
    if (v is num) return v.toString();
  }
  return null;
}

List? _extractList(dynamic json, List<String> keys, [int depth = 0]) {
  if (json is List) return json;
  if (json is Map && depth < 3) {
    for (final k in keys) {
      final v = json[k];
      if (v is List) return v;
    }
    for (final k in keys) {
      final v = json[k];
      if (v is Map) {
        final inner = _extractList(v, keys, depth + 1);
        if (inner != null) return inner;
      }
    }
  }
  return null;
}

int? _toInt(dynamic v) {
  if (v is int) return v;
  if (v is num) return v.round();
  if (v is String) return int.tryParse(normalizeDigits(v).trim());
  return null;
}

bool _isFalse(dynamic v) =>
    v == false || v == 0 || v == '0' || (v is String && v.toLowerCase() == 'false');

bool _isTrue(dynamic v) =>
    v == true || v == 1 || v == '1' || (v is String && v.toLowerCase() == 'true');

// ------------------------------ services -----------------------------------

List<ServiceItem> parseServices(dynamic json, {String? rawBody}) {
  Iterable<MapEntry<String?, dynamic>> entries;
  final list = _extractList(json, _listKeys);
  if (list != null) {
    entries = list.map((e) => MapEntry<String?, dynamic>(null, e));
  } else if (json is Map &&
      json.isNotEmpty &&
      json.values.every((v) => v is Map)) {
    // { "<id>": { ...service... } }
    entries = json.entries.map((e) => MapEntry<String?, dynamic>('${e.key}', e.value));
  } else {
    throw ApiException(ApiErrorKind.format, rawBody: rawBody);
  }

  final out = <ServiceItem>[];
  for (final entry in entries) {
    final e = entry.value;
    if (e is! Map) continue;
    final id = _firstOf(e, ['id', 'service_id', 'slug', 'key', 'code']) ?? entry.key;
    final name = _firstString(e, ['name', 'title', 'label', 'name_fa', 'title_fa']);
    if (id == null || name == null) continue;
    out.add(ServiceItem(
      id: id is num || id is String ? id as Object : id.toString(),
      name: name,
      nameEn: _firstString(e, ['name_en', 'title_en', 'label_en']),
      durationMinutes: _toInt(_firstOf(
          e, ['duration', 'minutes', 'duration_min', 'duration_minutes'])),
      description: _firstString(
          e, ['description', 'desc', 'details', 'description_fa', 'about']),
    ));
  }
  if (out.isEmpty && (list == null || list.isNotEmpty)) {
    throw ApiException(ApiErrorKind.format, rawBody: rawBody);
  }
  return out;
}

// ----------------------------- availability --------------------------------

SlotTime? _slotFromEntry(dynamic e) {
  if (e is String || e is num) return SlotTime.tryParse('$e');
  if (e is Map) {
    final flag = _firstOf(e, ['available', 'free', 'is_available', 'open']);
    if (flag != null && _isFalse(flag)) return null;
    final taken = _firstOf(e, ['booked', 'taken', 'reserved', 'busy']);
    if (taken != null && _isTrue(taken)) return null;
    final t = _firstString(e, ['time', 'start', 'from', 'label', 'value']);
    return t == null ? null : SlotTime.tryParse(t);
  }
  return null;
}

List<SlotTime> parseAvailability(dynamic json, {String? rawBody}) {
  final found = <SlotTime>[];
  final list = _extractList(json, _listKeys);
  if (list != null) {
    for (final e in list) {
      final s = _slotFromEntry(e);
      if (s != null) found.add(s);
    }
    if (found.isEmpty && list.isNotEmpty) {
      throw ApiException(ApiErrorKind.format, rawBody: rawBody);
    }
  } else if (json is Map) {
    // { "06:00": true, "06:30": false, ... }
    var sawTimeKey = false;
    json.forEach((k, v) {
      final s = SlotTime.tryParse('$k');
      if (s == null) return;
      sawTimeKey = true;
      final free = v is Map ? _slotFromEntry({'time': '$k', ...v}) != null : !_isFalse(v) && v != null;
      if (free) found.add(s);
    });
    if (!sawTimeKey) throw ApiException(ApiErrorKind.format, rawBody: rawBody);
  } else {
    throw ApiException(ApiErrorKind.format, rawBody: rawBody);
  }
  final unique = <SlotTime>{...found}.toList()
    ..sort((a, b) => a.totalMinutes.compareTo(b.totalMinutes));
  return unique;
}

// ------------------------------- booking -----------------------------------

/// Best-effort extraction of a human-readable message from an error body.
String? extractServerMessage(dynamic json) {
  if (json is Map) {
    for (final k in ['error', 'message', 'msg', 'errors', 'detail']) {
      final v = json[k];
      if (v is String && v.trim().isNotEmpty) return v.trim();
      if (v is List && v.isNotEmpty) {
        final parts = v.whereType<String>().where((s) => s.trim().isNotEmpty);
        if (parts.isNotEmpty) return parts.join('\n');
      }
      if (v is Map) {
        final inner = extractServerMessage(v);
        if (inner != null) return inner;
      }
    }
  }
  return null;
}

Map<String, String> _extractPayment(Map json) {
  final out = <String, String>{};
  void collect(String prefix, dynamic v) {
    if (v == null) return;
    if (v is Map) {
      v.forEach((k, inner) => collect(prefix.isEmpty ? '$k' : '$prefix.$k', inner));
    } else if (v is List) {
      for (var i = 0; i < v.length; i++) {
        collect('$prefix[$i]', v[i]);
      }
    } else {
      final s = v.toString().trim();
      if (s.isNotEmpty) out[prefix] = s;
    }
  }

  json.forEach((k, v) {
    final key = '$k'.toLowerCase();
    if (key.contains('pay') || key.contains('deposit')) collect('$k', v);
  });
  return out;
}

/// Turns a 2xx `book.php` response into a [BookingResult]. A booking counts as
/// made ONLY if the server returned a `ref` and did not flag a failure.
BookingResult parseBookingResponse(dynamic json, {String? rawBody, int? statusCode}) {
  if (json is! Map) {
    throw ApiException(ApiErrorKind.format, rawBody: rawBody, statusCode: statusCode);
  }
  final okFlag = _firstOf(json, ['ok', 'success']);
  if (okFlag != null && _isFalse(okFlag)) {
    throw ApiException(
      ApiErrorKind.rejected,
      serverMessage: extractServerMessage(json),
      rawBody: rawBody,
      statusCode: statusCode,
    );
  }
  Map source = json;
  var ref = _firstString(source, ['ref']);
  if (ref == null && json['data'] is Map) {
    source = json['data'] as Map;
    ref = _firstString(source, ['ref']);
  }
  if (ref == null) {
    final msg = extractServerMessage(json);
    throw ApiException(
      msg != null ? ApiErrorKind.rejected : ApiErrorKind.format,
      serverMessage: msg,
      rawBody: rawBody,
      statusCode: statusCode,
    );
  }
  return BookingResult(
    ref: ref,
    status: _firstString(source, ['status']) ?? _firstString(json, ['status']),
    payment: _extractPayment(source),
    serverMessage: _firstString(json, ['message', 'msg']),
  );
}
