import 'dart:async';
import 'dart:convert';
import 'dart:io' show IOException;

import 'package:http/http.dart' as http;

import '../../core/config/app_config.dart';
import 'api_exception.dart';
import 'response_parsers.dart';

/// A successfully received (2xx) and JSON-decoded response.
class ApiResponse {
  const ApiResponse({required this.json, required this.rawBody, required this.statusCode});

  final dynamic json;
  final String rawBody; // truncated, for diagnostics only
  final int statusCode;
}

/// Thin HTTP + JSON layer. It knows nothing about services or bookings.
class ApiClient {
  ApiClient({http.Client? client, String? baseUrl, Duration? timeout})
      : _client = client ?? http.Client(),
        _base = baseUrl ?? AppConfig.apiBase,
        _timeout = timeout ?? AppConfig.requestTimeout;

  final http.Client _client;
  final String _base;
  final Duration _timeout;

  Uri _uri(String path, [Map<String, String>? query]) {
    final uri = Uri.parse('$_base$path');
    return (query == null || query.isEmpty)
        ? uri
        : uri.replace(queryParameters: query);
  }

  Future<ApiResponse> get(String path, {Map<String, String>? query}) async {
    final response = await _send(() => _client.get(
          _uri(path, query),
          headers: const {'Accept': 'application/json'},
        ));
    return _decode(response);
  }

  Future<ApiResponse> post(String path, Map<String, dynamic> body) async {
    final response = await _send(() => _client.post(
          _uri(path),
          headers: const {
            'Accept': 'application/json',
            'Content-Type': 'application/json; charset=utf-8',
          },
          body: jsonEncode(body),
        ));
    return _decode(response);
  }

  Future<http.Response> _send(Future<http.Response> Function() request) async {
    try {
      return await request().timeout(_timeout);
    } on TimeoutException {
      throw const ApiException(ApiErrorKind.timeout);
    } on http.ClientException {
      throw const ApiException(ApiErrorKind.network);
    } on IOException {
      // SocketException, HandshakeException, TlsException, ...
      throw const ApiException(ApiErrorKind.network);
    }
  }

  ApiResponse _decode(http.Response response) {
    var text = utf8.decode(response.bodyBytes, allowMalformed: true);
    if (text.startsWith('﻿')) text = text.substring(1);
    final status = response.statusCode;
    final snippet = text.length > 600 ? '${text.substring(0, 600)}…' : text;

    dynamic json;
    var parsed = true;
    try {
      json = jsonDecode(text);
    } on FormatException {
      parsed = false;
    }

    if (status < 200 || status >= 300) {
      final message = parsed ? extractServerMessage(json) : null;
      throw ApiException(
        message != null ? ApiErrorKind.rejected : ApiErrorKind.server,
        serverMessage: message,
        statusCode: status,
        rawBody: snippet,
      );
    }
    if (!parsed) {
      throw ApiException(ApiErrorKind.format, statusCode: status, rawBody: snippet);
    }
    return ApiResponse(json: json, rawBody: snippet, statusCode: status);
  }

  void close() => _client.close();
}
