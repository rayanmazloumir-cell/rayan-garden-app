import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(child: _Header()),
          SliverToBoxAdapter(child: _Hero()),
          SliverToBoxAdapter(child: _Actions()),
          SliverToBoxAdapter(child: _Intro()),
          const SliverToBoxAdapter(child: SizedBox(height: 28)),
        ],
      ),
    ),
  );
}

class _Header extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 14, 20, 10),
    child: Row(children: [
      Container(
        width: 48, height: 48,
        decoration: BoxDecoration(
          color: AppColors.darkGreen,
          borderRadius: BorderRadius.circular(15),
        ),
        alignment: Alignment.center,
        child: const Text('R', style: TextStyle(
          color: AppColors.gold, fontSize: 29, fontWeight: FontWeight.w800,
          fontFamily: 'serif',
        )),
      ),
      const SizedBox(width: 12),
      const Expanded(child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('رایان گاردن', style: TextStyle(
            color: AppColors.darkGreen, fontSize: 21, fontWeight: FontWeight.w800,
          )),
          SizedBox(height: 2),
          Text('RAYAN GARDEN', style: TextStyle(
            color: AppColors.gold, fontSize: 10, letterSpacing: 2.2,
            fontWeight: FontWeight.w700,
          )),
        ],
      )),
      TextButton(onPressed: () {}, child: const Text('EN')),
    ]),
  );
}

class _Hero extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 8, 16, 18),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(26),
      child: Stack(alignment: Alignment.bottomRight, children: [
        AspectRatio(
          aspectRatio: 4 / 3,
          child: Image.asset(
            'assets/images/rayan_garden_home.png',
            width: double.infinity,
            fit: BoxFit.cover,
          ),
        ),
        Container(
          height: 150,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [Colors.transparent, Color(0xCC10251E)],
            ),
          ),
        ),
        const Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('آمل · مازندران', style: TextStyle(
                color: Color(0xFFE6D7AD), fontSize: 14, fontWeight: FontWeight.w600,
              )),
              SizedBox(height: 7),
              Text('لحظه‌های خاص،\nدر باغی متفاوت', style: TextStyle(
                color: Colors.white, fontSize: 27, height: 1.35,
                fontWeight: FontWeight.w800,
              )),
            ],
          ),
        ),
      ]),
    ),
  );
}

class _Actions extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: Column(children: [
      ElevatedButton.icon(
        onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('در مرحله بعد، صفحه انتخاب خدمات اضافه می‌شود.')),
        ),
        icon: const Icon(Icons.calendar_month_rounded),
        label: const Text('رزرو آنلاین'),
      ),
      const SizedBox(height: 12),
      OutlinedButton.icon(
        onPressed: () {},
        icon: const Icon(Icons.phone_in_talk_rounded),
        label: const Text('تماس تلفنی'),
      ),
    ]),
  );
}

class _Intro extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(22, 26, 22, 0),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('تجربه‌ای برای ثبت خاطره‌ها', style: TextStyle(
        color: AppColors.darkGreen, fontSize: 19, fontWeight: FontWeight.w800,
      )),
      const SizedBox(height: 8),
      Text(
        'باغ عکاسی و کافه رایان گاردن؛ فضایی سرسبز برای عکاسی عروس و داماد، خانواده، کودک و لحظه‌های خاص شما.',
        style: TextStyle(color: AppColors.ink.withOpacity(.78), fontSize: 14, height: 1.9),
      ),
    ]),
  );
}
