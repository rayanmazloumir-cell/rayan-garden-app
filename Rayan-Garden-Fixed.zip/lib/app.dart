import 'package:flutter/material.dart';
import 'core/theme/app_theme.dart';
import 'screens/home/home_screen.dart';

class RayanGardenApp extends StatelessWidget {
  const RayanGardenApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Rayan Garden',
    debugShowCheckedModeBanner: false,
    theme: AppTheme.light,
    locale: const Locale('fa'),
    home: const Directionality(
      textDirection: TextDirection.rtl,
      child: HomeScreen(),
    ),
  );
}
