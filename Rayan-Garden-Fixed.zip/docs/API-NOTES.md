# Next API integration

Base URL: https://rayangarden.com/api/

Planned calls:
- GET services.php
- GET availability.php?date=YYYY-MM-DD&service=<id>
- POST book.php (JSON)

The exact parameter and response contract for track.php must be confirmed
before implementing reservation tracking. No undocumented API is assumed.
