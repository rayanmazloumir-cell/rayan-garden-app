# API integration notes

Base URL: `https://rayangarden.com/api/`

## Documented contract (used by the app)
| Call | Notes |
|------|-------|
| `GET services.php` | Service list. Service ids are taken from this response, never guessed. |
| `GET availability.php?date=YYYY-MM-DD&service=<id>` | Date is Gregorian. |
| `POST book.php` (JSON) | Fields: `service, date, time, name, phone, notes, lang, website, elapsed` |

Rules enforced in the app:
- `website` is always sent empty (honeypot).
- `elapsed` is the real time since the customer-details form opened and is always >= 2500 ms.
- Dates shown to the customer are Jalali; dates sent to the API are Gregorian `YYYY-MM-DD`.
- The booking window is today .. +120 days (Iran time, UTC+03:30); times closer than 60 minutes are hidden.
- A booking is shown as successful ONLY if the server returns a `ref`. Server errors are shown to the user.
- Not used yet: `track.php` (contract not confirmed).

## NOT documented -> must be confirmed (nothing was guessed silently)
The exact JSON shape of these responses was not available. The parsers
(`lib/data/api/response_parsers.dart`) are tolerant and accept:

1. `services.php`: a JSON list, or an object containing the list under `services`, `data`, `items` or `result`.
   Each item needs an id (`id` / `service_id` / `slug` / `key` / `code`) and a name (`name` / `title` / `label`).
   Optional: duration (`duration` / `minutes` / `duration_min`), description (`description` / `desc`), English name (`name_en`).
2. `availability.php`: a list of `"HH:MM"` strings or objects with `time` (and optional `available`),
   under `slots` / `times` / `available` / `data`, or a `{"06:00": true}` map.
3. `book.php`: success = a `ref` field (top level or inside `data`) and no `ok/success: false`;
   `status` is shown as received; any key containing `pay` or `deposit` is displayed as payment info;
   an error message is read from `error` / `message` / `msg`.

If a real response does not match, the app shows "technical details" (HTTP status + raw body) on the error
screen. To confirm, open these in a browser and compare:
- `https://rayangarden.com/api/services.php`
- `https://rayangarden.com/api/availability.php?date=<YYYY-MM-DD>&service=<id from the first link>`

Fallback: if the server sends no duration for a service, the durations from the business rules are used
(wedding 180, formality 180, child 60, family 60, portrait 60, cafe 120, location 120, visit 30).
